char brojac;

void kasnjenje() {
  Delay_ms(200);                                  // uvodi se funkcija "kasnjenje" od 200ms
}

void main() {

  TRISA = 0x00;
  TRISB = 0x00;                                  // pinovi se postavljaju kao izlazni
  TRISC = 0x00;
  TRISD = 0x00;


  LATA = 0x00;
  LATB = 0x00;                                  // LED na svakom pinu se postavlja na pocetnu vrednost
  LATC = 0x00;                                  // odnosno na nulu
  LATD = 0x00;


  while (1) {
    for (brojac = 0; brojac < 8; brojac++){
      LATA = 0x00;
      kasnjenje();
      LATA = 0x02;                              //prolazi se kroz for petlju 8 puta
      LATB |= 1 << brojac;                      // i pri svakoj inicijalizaciji se pali sledeci red
      LATC = 0x00;                              //dioda u kolonama B i D koje prati
      kasnjenje();                              //paljenje i gasenje dioda u drugom redu kolona A i C
      LATC = 0x02;
      LATD |= 1 << brojac;

      kasnjenje();
    }
    

    brojac = 0;                                 //Kada se upale sve diode, brojac se vraca na nulu
    while (brojac < 8) {
                                                //Sledi gasenje dioda u kolonama B i D, dok su
      LATB &= ~(1 << brojac);                   //diode A i C u drugom redu upaljene
      LATD &= ~(1 << brojac);

      kasnjenje();
      brojac++;
    }
  }
}